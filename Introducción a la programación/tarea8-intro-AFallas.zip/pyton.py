class Figure:
    def tring(self):
        triangulo = "" 
        X = int (input("Ingrese altura de la figura:"))
        for num in range(X):
            triangulo = triangulo + "*" 
            print (triangulo)
            
        
