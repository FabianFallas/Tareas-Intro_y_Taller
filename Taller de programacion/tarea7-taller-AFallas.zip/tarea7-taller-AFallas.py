### CAMBIO DE DECIMAL A BINARIO
def binario(num):
    if isinstance (num, int):
        return binario_aux(num, 0)
    else:
        return "no es un numero"
def binario_aux(num, contador):
    if num == 0:
        return 0
    else:
        return num % 2 * 10** contador + binario_aux (num // 2, contador + 1)





########################################################################################



### CAMBIO DE BINARIO A DECIMAL
def decimal(num):
    if isinstance (num, int) and extra (num):
        return decimal_aux(num,0)
    else:
        return "no es binario"
def decimal_aux (num, contador):
    if num == 0:
        return 0
    else:
        return(num % 10)*(2**contador) + decimal_aux(num //10, contador + 1)
### OPCION DE VALIDACION PARA QUE SEA BINARIO
def extra(num):
    if num == 1:
        return True
    elif num % 10 == 0 or num % 10 == 1:
        return extra(num // 10)
    else:
        return False 
